package com.beTrendy.dbHandler;
import java.sql.*;

public class DataFetcher {
	public static String fetchPassword(String uname) {
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="system";
		String pwd="SYSTEM";
		String sql="SELECT password FROM details WHERE email=?";
		String dbPass="";
		 try {
	            Class.forName(driver);
	            try (Connection con = DriverManager.getConnection(url, user, pwd);
	                 PreparedStatement ps = con.prepareStatement(sql)) {

	                ps.setString(1, uname);
	                try (ResultSet rs = ps.executeQuery()) {
	                    if (rs.next()) {
	                        dbPass = rs.getString(1);
	                    } else {
	                        System.out.println("No matching record found for uname: " + uname);
	                    }
	                }
	            }
	        }
		catch(Exception ex) {
			System.out.println("login issues");
			ex.printStackTrace();
			
		}
		return dbPass;
	}
}
