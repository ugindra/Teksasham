package com.beTrendy.dbHandler;
import java.sql.*;
public class DataInjector {
	public static String addDetails(String uname,String email,String pass) {
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String user="system";
		String pwd="SYSTEM";
		String sql1="INSERT INTO details VALUES(?,?,?)";
		
		String regStatus="";
		try {
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url,user,pwd);
			PreparedStatement ps1=con.prepareStatement(sql1);
			
				ps1.setString(1,uname);
				ps1.setString(2,email);
				ps1.setString(3,pass);
				ps1.executeUpdate();
				
				regStatus="success";
		}
		catch(Exception ex) {
			System.out.println("Problem adding details");
			ex.printStackTrace();
			regStatus="failed";
		}
		finally {
			return regStatus;
		}
		
	}
}
