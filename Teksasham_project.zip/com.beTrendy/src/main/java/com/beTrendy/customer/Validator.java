package com.beTrendy.customer;

import com.beTrendy.dbHandler.DataFetcher;

public class Validator {
	public static boolean isValid(String uname,String pwd) {
		String dbPass=DataFetcher.fetchPassword(uname);
		if(pwd.equals(dbPass)) {
			return true;
		}
		else {
			return false;
		}
	}
}
