package com.beTrendy.customer;

import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.beTrendy.dbHandler.DataInjector;

@WebServlet("/reg")
public class RegisterServlet extends HttpServlet{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException {
		String uname=req.getParameter("username");
		String email=req.getParameter("email");
		String pass=req.getParameter("password");
		String status=DataInjector.addDetails(uname,email,pass);
		res.sendRedirect("login.jsp");
			
	}
}
