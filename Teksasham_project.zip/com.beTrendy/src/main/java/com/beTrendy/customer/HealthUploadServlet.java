// ContentServlet.java
package com.beTrendy.customer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/healthUploadServlet")
public class HealthUploadServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String heading = request.getParameter("heading");
        String content = request.getParameter("content");

        try {
            // Database connection
        	String driver="oracle.jdbc.driver.OracleDriver";
    		String url="jdbc:oracle:thin:@localhost:1521:xe";
    		String user="system";
    		String pwd="SYSTEM";
            Class.forName(driver);
            Connection connection = DriverManager.getConnection(url, user, pwd);

            // Insert heading and content into the database
            String insertQuery = "INSERT INTO health_content (heading, content) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, heading);
            preparedStatement.setString(2, content);
            preparedStatement.executeUpdate();

            // Close database resources
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect back to the upload page or any other page
        response.sendRedirect("healthCare.jsp"); // Replace with the appropriate page
    }
}
