package com.beTrendy.customer;
import java.io.IOException;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/log")
public class LoginServlet extends HttpServlet {
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException {
		String uname=req.getParameter("Email");
		String pwd=req.getParameter("password");
		boolean val = Validator.isValid(uname,pwd);
		if(val==false) {
			req.getSession().setAttribute("username", uname);
			res.sendRedirect("home.jsp");
		}
		else {
			res.sendRedirect("login.jsp");
		}
	}
}
